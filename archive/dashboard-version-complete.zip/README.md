# Theraply — Dashboard de pilotage

Tableau de bord de la cheffe de projet Theraply. Toutes les statistiques sont calculées à partir des données saisies : aucune valeur codée en dur, aucune donnée fictive (les données de démo sont optionnelles).

React 19 · Vite 8 · Tailwind CSS 4 · Recharts · @dnd-kit · lucide-react. Pas de backend : les données sont enregistrées dans le navigateur (localStorage).

## Commandes

| Commande | Rôle |
| --- | --- |
| `npm run dev` | Serveur de développement |
| `npm run build` | Build de production (`dist/`) |
| `npm run lint` | Analyse du code (oxlint) |
| `npm test` | Tests unitaires des fonctions métier (`node --test`, dossier `tests/`) |
| `npm run smoke` | Rend chaque page côté Node (vide, démo, ancienne sauvegarde v1) pour détecter les erreurs d'exécution |

## Raccourcis

- `Ctrl+K` : palette de commandes (chercher, créer une tâche, naviguer, exporter)
- `Ctrl+S` : sauvegarder · `Ctrl+Z` : annuler la dernière action
- Saisie rapide : `Écrire l'API RDV @sahar #backend !haute 30/09 ~3`
  (`@membre`, `#module`, `!haute|moyenne|basse`, `JJ/MM` ou `demain`, `~estimation`)

## Organisation du code

```
src/
  data/        constantes, état vide, données de démo, migrations du format de sauvegarde
  utils/       logique métier pure et testée (dates, tâches, sprints, stats, filtres, rapport…)
  hooks/       useSaveData (persistance), useDashboardStats, useTaskActions, useWeeklyReport
  services/    storage.js : adaptateur localStorage (à remplacer par une API plus tard)
  components/  composants d'affichage (dashboard, charts, tasks, settings, ui)
  theme/       couleurs sémantiques (statuts, priorités)
tests/         tests unitaires
```

## Format des données

Le format de sauvegarde est versionné (`version: 3`). Les anciennes sauvegardes (v1 avec `deadline: "Lundi"`, v2) sont converties automatiquement au chargement ou à l'import, sans perte : voir `src/data/migrations.js`.

Pour brancher un backend, fournir à `useSaveData` un adaptateur avec la même interface que `localStorageAdapter` (`load`, `save`, `clear`).

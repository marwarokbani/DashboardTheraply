/**
 * App — Composant racine du dashboard Theraply.
 *
 * Orchestre : thème clair/sombre, navigation, données (useSaveData),
 * statistiques (useDashboardStats), actions sur les tâches (useTaskActions),
 * panneau d'édition, notifications et palette de commandes (Ctrl+K).
 */
import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import { Download, FileText, Flag, Moon, Save } from 'lucide-react';
import { useDashboardStats } from './hooks/useDashboardStats';
import { useSaveData } from './hooks/useSaveData';
import { useTaskActions } from './hooks/useTaskActions';
import { useWeeklyReport } from './hooks/useWeeklyReport';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import TasksSection from './components/TasksSection';
import MilestonesSection from './components/MilestonesSection';
import TeamSection from './components/TeamSection';
import CalendarSection from './components/CalendarSection';
import Toast from './components/Toast';
import WelcomeScreen from './components/WelcomeScreen';
import SettingsPage from './components/SettingsPage';
import CommandPalette from './components/CommandPalette';
import TaskDrawer from './components/tasks/TaskDrawer';
import KpiCards from './components/dashboard/KpiCards';
import TodayFocus from './components/dashboard/TodayFocus';
import StatsSkeleton from './components/dashboard/StatsSkeleton';
import ScopeSelect from './components/dashboard/ScopeSelect';
import ReportMenu from './components/dashboard/ReportMenu';
import WeeklyReport from './components/dashboard/WeeklyReport';
import { getActiveSprint } from './utils/sprints';

// Les graphiques (Recharts, lourd) sont chargés à la demande
const StatsSection = lazy(() => import('./components/StatsSection'));

/** Titre affiché dans l'en-tête pour chaque section. */
const PAGE_TITLES = {
  dashboard: 'Vue d’ensemble',
  tasks: 'Tâches',
  milestones: 'Jalons',
  team: 'Équipe',
  calendar: 'Calendrier',
  settings: 'Paramètres',
};

/** Thème initial : choix mémorisé, sinon préférence du système. */
function getInitialDarkMode() {
  try {
    const stored = localStorage.getItem('theraply-theme');
    if (stored) return stored === 'dark';
  } catch {
    // localStorage indisponible : on suit le système
  }
  return window.matchMedia('(prefers-color-scheme: dark)').matches;
}

export default function App({ initialSection = 'dashboard' }) {
  // ── Thème ──
  const [darkMode, setDarkMode] = useState(getInitialDarkMode);
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    try {
      localStorage.setItem('theraply-theme', darkMode ? 'dark' : 'light');
    } catch {
      // préférence non mémorisée, sans conséquence
    }
  }, [darkMode]);

  // ── Navigation ──
  const [activeSection, setActiveSection] = useState(initialSection);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => window.innerWidth < 1024);
  const [paletteOpen, setPaletteOpen] = useState(false);

  const navigate = useCallback((section) => {
    setActiveSection(section);
    if (window.innerWidth < 1024) setSidebarCollapsed(true);
  }, []);

  // ── Données, statistiques, actions ──
  const {
    data, updateData, save, undo, canUndo, hasUnsavedChanges, lastSaved,
    toast, showToast, exportData, importData, resetData, loadDemoData,
  } = useSaveData();
  const actions = useTaskActions(data, updateData, showToast);

  const [filters, setFilters] = useState({ scope: 'active', unit: 'tasks', moduleMode: 'tasks' });
  const updateFilters = (patch) => setFilters((f) => ({ ...f, ...patch }));
  // Un sprint supprimé ne peut plus servir de périmètre : retour au sprint actif
  const scopeValue = ['active', 'all', 'backlog'].includes(filters.scope) || data.sprints.some((s) => s.id === filters.scope) ? filters.scope : 'active';
  const stats = useDashboardStats(data, { ...filters, scope: scopeValue });
  const report = useWeeklyReport(data, scopeValue, showToast);

  // ── Panneau d'édition d'une tâche ──
  const [openTaskId, setOpenTaskId] = useState(null);
  const openTask = data.tasks.find((t) => t.id === openTaskId) || null;
  const closeDrawer = useCallback(() => setOpenTaskId(null), []);

  // ── Palette de commandes (Ctrl/Cmd+K) ──
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((open) => !open);
      } else if (e.key === 'Escape') {
        setPaletteOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const commands = useMemo(() => [
    { id: 'cmd:save', label: 'Sauvegarder', meta: 'Ctrl+S', icon: Save, run: () => save() },
    { id: 'cmd:theme', label: darkMode ? 'Passer en mode clair' : 'Passer en mode sombre', icon: Moon, run: () => setDarkMode((d) => !d) },
    { id: 'cmd:sprint', label: 'Gérer les sprints', icon: Flag, run: () => navigate('settings') },
    { id: 'cmd:export', label: 'Exporter les données (JSON)', icon: Download, run: exportData },
    { id: 'cmd:report-pdf', label: 'Rapport hebdomadaire en PDF', icon: FileText, run: report.print },
    { id: 'cmd:report-md', label: 'Rapport hebdomadaire en Markdown', icon: FileText, run: report.downloadMarkdown },
  ], [darkMode, save, exportData, navigate, report.print, report.downloadMarkdown]);

  // Action d'un toast : « Annuler » déclenche l'annulation globale
  const handleToastAction = (action) => (action.undo ? undo() : action.onClick?.());

  // ── Contenu ──
  const isEmpty = data.tasks.length === 0 && data.sprints.length === 0;
  const tasksProps = {
    data,
    tasks: stats.scope.tasks,
    scopeLabel: stats.scope.label,
    actions,
    onOpenTask: setOpenTaskId,
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <>
            <KpiCards kpis={stats.kpis} scope={stats.scope} unit={stats.unit} />
            <TodayFocus items={stats.todayFocus} teamMembers={data.teamMembers} upcomingCount={stats.dueSoon.upcoming.length} onOpenTask={setOpenTaskId} />
            <Suspense fallback={<StatsSkeleton />}>
              <StatsSection stats={stats} data={data} filters={filters} onFiltersChange={updateFilters} />
            </Suspense>
            <TasksSection {...tasksProps} />
          </>
        );
      case 'tasks':
        return <TasksSection {...tasksProps} title="Toutes les tâches" />;
      case 'milestones':
        return <MilestonesSection data={data} updateData={updateData} />;
      case 'team':
        return <TeamSection data={data} updateData={updateData} onOpenTask={setOpenTaskId} />;
      case 'calendar':
        return <CalendarSection data={data} />;
      case 'settings':
        return (
          <SettingsPage
            data={data}
            updateData={updateData}
            showToast={showToast}
            onReset={resetData}
            onExport={exportData}
            onImport={importData}
            onLoadDemo={loadDemoData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <>
    <div className="flex h-screen overflow-hidden bg-app no-print">
      <Sidebar
        activeSection={activeSection}
        onNavigate={navigate}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed((c) => !c)}
      />

      <main className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden flex flex-col">
        <div className="max-w-7xl w-full min-w-0 mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 flex-1 flex flex-col">
          <Header
            title={PAGE_TITLES[activeSection]}
            activeSprint={getActiveSprint(data.sprints)}
            hasUnsavedChanges={hasUnsavedChanges}
            lastSaved={lastSaved}
            onSave={save}
            onUndo={undo}
            canUndo={canUndo}
            darkMode={darkMode}
            onToggleDarkMode={() => setDarkMode((d) => !d)}
            onToggleSidebar={() => setSidebarCollapsed((c) => !c)}
            onOpenCommandPalette={() => setPaletteOpen(true)}
          >
            {!isEmpty && ['dashboard', 'tasks'].includes(activeSection) && (
              <>
                <ScopeSelect sprints={data.sprints} value={scopeValue} onChange={(scope) => updateFilters({ scope })} />
                <ReportMenu onPrint={report.print} onDownloadMarkdown={report.downloadMarkdown} onCopyMarkdown={report.copyMarkdown} />
              </>
            )}
          </Header>

          {isEmpty && activeSection === 'dashboard' ? (
            <WelcomeScreen onAddTask={actions.addQuickTask} onNavigate={navigate} onLoadDemo={loadDemoData} />
          ) : (
            renderContent()
          )}
        </div>
      </main>

      {openTask && (
        <TaskDrawer
          key={openTask.id}
          task={openTask}
          data={data}
          onClose={closeDrawer}
          onChange={actions.editTask}
          onDelete={actions.deleteTasks}
        />
      )}

      <Toast toast={toast} onAction={handleToastAction} onClose={() => showToast(null)} />

      {paletteOpen && (
        <CommandPalette
          data={data}
          commands={commands}
          onClose={() => setPaletteOpen(false)}
          onNavigate={navigate}
          onOpenTask={setOpenTaskId}
          onAddTask={actions.addQuickTask}
        />
      )}
    </div>

    {/* Version imprimable du rapport (PDF) */}
    {report.printReport && (
      <div className="print-only">
        <WeeklyReport report={report.printReport} />
      </div>
    )}
    </>
  );
}

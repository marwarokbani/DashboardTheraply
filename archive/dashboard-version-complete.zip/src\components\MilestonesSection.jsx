/**
 * MilestonesSection — Jalons du projet, groupés par module.
 * Cocher / décocher, ajouter, supprimer. L'avancement de chaque module
 * est dérivé des jalons cochés.
 */
import { useState } from 'react';
import { Check, ChevronDown, ChevronRight, Plus, Trash2 } from 'lucide-react';
import { addMilestone, removeMilestone, toggleMilestone } from '../utils/milestones';

/** Groupe de jalons d'un module (repliable). */
function MilestoneGroup({ title, color, milestones, onToggle, onRemove, onAdd }) {
  const [expanded, setExpanded] = useState(true);
  const [draft, setDraft] = useState('');
  const done = milestones.filter((ms) => ms.completed).length;
  const progress = milestones.length ? Math.round((done / milestones.length) * 100) : 0;

  const submit = (e) => {
    e.preventDefault();
    if (!draft.trim()) return;
    onAdd(draft);
    setDraft('');
  };

  return (
    <div className="card overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        aria-expanded={expanded}
        className="w-full flex items-center gap-3 px-5 py-4 hover:bg-[var(--bg-tertiary)] cursor-pointer"
      >
        {expanded ? <ChevronDown className="w-4 h-4 text-tertiary" /> : <ChevronRight className="w-4 h-4 text-tertiary" />}
        <span className="w-3 h-3 rounded-full shrink-0" style={{ background: color }} aria-hidden />
        <span className="text-sm font-semibold flex-1 text-left text-primary">{title}</span>
        <span className="hidden sm:flex items-center gap-2 min-w-[140px]">
          <span className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--bg-tertiary)' }}>
            <span className="block h-full rounded-full transition-all duration-500" style={{ width: `${progress}%`, background: color }} />
          </span>
          <span className="text-xs font-semibold w-16 text-right tabular-nums text-secondary">{done}/{milestones.length}</span>
        </span>
      </button>

      {expanded && (
        <div className="px-5 pb-4 space-y-1">
          {milestones.map((ms) => (
            <div key={ms.id} className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[var(--bg-subtle)] group">
              <button
                type="button"
                role="checkbox"
                aria-checked={ms.completed}
                aria-label={ms.title}
                onClick={() => onToggle(ms.id)}
                className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 border-2 cursor-pointer transition-colors
                  ${ms.completed ? 'border-[var(--status-done)] bg-[var(--status-done)]' : 'border-[var(--border-strong)]'}`}
              >
                {ms.completed && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
              </button>
              <span className={`flex-1 text-sm ${ms.completed ? 'line-through text-tertiary' : 'text-primary'}`}>{ms.title}</span>
              <button
                type="button"
                onClick={() => onRemove(ms)}
                className="p-1 rounded-lg opacity-0 group-hover:opacity-100 focus:opacity-100 text-tertiary hover:text-danger cursor-pointer"
                aria-label={`Supprimer le jalon ${ms.title}`}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
          <form onSubmit={submit} className="flex items-center gap-2 px-3 pt-1">
            <Plus className="w-4 h-4 text-tertiary shrink-0" aria-hidden />
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Ajouter un jalon…"
              aria-label={`Ajouter un jalon à ${title}`}
              className="flex-1 bg-transparent text-sm outline-none py-1.5 text-primary placeholder:text-[var(--text-tertiary)]"
            />
          </form>
        </div>
      )}
    </div>
  );
}

export default function MilestonesSection({ data, updateData }) {
  const { modules, milestones } = data;
  const orphans = milestones.filter((ms) => !modules.some((m) => m.id === ms.module));

  const toggle = (id) => updateData((prev) => ({ ...prev, milestones: toggleMilestone(prev.milestones, id) }));
  const add = (moduleId) => (title) =>
    updateData((prev) => ({ ...prev, milestones: addMilestone(prev.milestones, { title, module: moduleId }) }));
  const remove = (ms) => {
    if (!confirm(`Supprimer le jalon « ${ms.title} » ?`)) return;
    updateData((prev) => ({ ...prev, milestones: removeMilestone(prev.milestones, ms.id) }));
  };

  return (
    <section className="space-y-4" aria-labelledby="milestones-title">
      <h2 id="milestones-title" className="section-title">Jalons du projet</h2>

      {modules.length === 0 && orphans.length === 0 ? (
        <p className="settings-empty">Ajoutez des modules dans Paramètres pour y rattacher des jalons.</p>
      ) : (
        <div className="space-y-3">
          {modules.map((mod) => (
            <MilestoneGroup
              key={mod.id}
              title={mod.name}
              color={mod.color}
              milestones={milestones.filter((ms) => ms.module === mod.id)}
              onToggle={toggle}
              onRemove={remove}
              onAdd={add(mod.id)}
            />
          ))}
          {orphans.length > 0 && (
            <MilestoneGroup title="Sans module" color="var(--status-todo)" milestones={orphans} onToggle={toggle} onRemove={remove} onAdd={add(null)} />
          )}
        </div>
      )}
    </section>
  );
}

/**
 * StatsSection — Grille des graphiques du dashboard :
 * burndown en grand, puis statuts, charge par membre, vélocité, modules.
 * Toutes les valeurs viennent de useDashboardStats (aucun calcul ici).
 */
import BurndownChart from './charts/BurndownChart';
import StatusDonut from './charts/StatusDonut';
import WorkloadChart from './charts/WorkloadChart';
import VelocityChart from './charts/VelocityChart';
import ModuleProgress from './charts/ModuleProgress';
import SegmentedControl from './ui/SegmentedControl';

const UNITS = [
  { value: 'tasks', label: 'Tâches' },
  { value: 'points', label: 'Points' },
];

export default function StatsSection({ stats, data, filters, onFiltersChange }) {
  const { unit } = stats;
  const { moduleMode } = filters;
  const unitToggle = stats.hasEstimates && (
    <SegmentedControl label="Unité" options={UNITS} value={unit} onChange={(value) => onFiltersChange({ unit: value })} size="sm" />
  );

  return (
    <section className="space-y-4" aria-label="Statistiques">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <BurndownChart burndown={stats.burndown} sprint={stats.scope.sprint} unit={unit} actions={unitToggle} className="xl:col-span-2" />
        <StatusDonut distribution={stats.statusDistribution} unit={unit} />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        <WorkloadChart workload={stats.workload} teamMembers={data.teamMembers} />
        <VelocityChart velocity={stats.velocity} unit={unit} />
        <ModuleProgress progress={stats.moduleProgress} mode={moduleMode} onModeChange={(value) => onFiltersChange({ moduleMode: value })} />
      </div>
    </section>
  );
}

/**
 * TeamSection — Espace équipe : une carte par membre (charge, complétion,
 * retards, tâche en cours) et le fil « Notes & blocages ».
 */
import { useMemo, useState } from 'react';
import { AlertTriangle, MessageSquare, Plus, X, Clock } from 'lucide-react';
import { calcWorkloadByMember } from '../utils/stats';
import { generateId } from '../utils/ids';
import { findById } from '../utils/team';
import Avatar from './ui/Avatar';
import { EmptyState } from './charts/ChartCard';

function MemberCard({ member, stats, onOpenTask }) {
  const current = stats.currentTasks[0];
  return (
    <article className="card p-5">
      <div className="flex items-center gap-3 mb-4">
        <Avatar member={member} size="lg" />
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-primary truncate">{member.name}</h3>
          {member.role && <p className="text-xs text-tertiary truncate">{member.role}</p>}
        </div>
      </div>

      <dl className="grid grid-cols-3 gap-2 mb-4 text-center">
        <div className="stat-box"><dt>Ouvertes</dt><dd>{stats.open}</dd></div>
        <div className="stat-box"><dt>Terminées</dt><dd>{stats.done}</dd></div>
        <div className="stat-box"><dt>Complétion</dt><dd>{stats.completion === null ? '—' : `${stats.completion} %`}</dd></div>
      </dl>

      {stats.overdue > 0 && (
        <p className="text-xs text-danger flex items-center gap-1.5 mb-2">
          <AlertTriangle className="w-3.5 h-3.5" aria-hidden /> {stats.overdue} tâche{stats.overdue > 1 ? 's' : ''} en retard
        </p>
      )}

      {current ? (
        <button type="button" onClick={() => onOpenTask?.(current.id)} className="w-full flex items-start gap-2 p-3 rounded-lg text-left text-xs hover:bg-[var(--bg-tertiary)] cursor-pointer" style={{ background: 'var(--bg-subtle)' }}>
          <Clock className="w-3.5 h-3.5 mt-0.5 shrink-0" style={{ color: 'var(--status-progress)' }} aria-hidden />
          <span>
            <span className="block text-tertiary">En cours{stats.currentTasks.length > 1 ? ` (+${stats.currentTasks.length - 1})` : ''}</span>
            <span className="block text-primary mt-0.5">{current.title}</span>
          </span>
        </button>
      ) : (
        <p className="p-3 rounded-lg text-xs text-center text-tertiary" style={{ background: 'var(--bg-subtle)' }}>Aucune tâche en cours</p>
      )}
    </article>
  );
}

export default function TeamSection({ data, updateData, onOpenTask }) {
  const [newNote, setNewNote] = useState('');
  const [newNoteType, setNewNoteType] = useState('note');
  const workload = useMemo(() => calcWorkloadByMember(data.tasks, data.teamMembers), [data.tasks, data.teamMembers]);
  const notes = [...data.notes].sort((a, b) => b.timestamp.localeCompare(a.timestamp));

  const addNote = (e) => {
    e.preventDefault();
    if (!newNote.trim()) return;
    const note = {
      id: generateId('note'),
      author: data.settings.currentUserId,
      text: newNote.trim(),
      timestamp: new Date().toISOString(),
      type: newNoteType,
    };
    updateData((prev) => ({ ...prev, notes: [...prev.notes, note] }));
    setNewNote('');
  };

  const removeNote = (noteId) => {
    updateData((prev) => ({ ...prev, notes: prev.notes.filter((n) => n.id !== noteId) }));
  };

  return (
    <section className="space-y-4" aria-labelledby="team-title">
      <h2 id="team-title" className="section-title">Équipe</h2>

      {data.teamMembers.length === 0 ? (
        <div className="card"><EmptyState message="Ajoutez les membres de l'équipe dans Paramètres." /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {data.teamMembers.map((member) => (
            <MemberCard key={member.id} member={member} stats={workload.items.find((w) => w.id === member.id)} onOpenTask={onOpenTask} />
          ))}
        </div>
      )}

      <section className="card p-5" aria-labelledby="notes-title">
        <h3 id="notes-title" className="card-title flex items-center gap-2 mb-4">
          <MessageSquare className="w-4 h-4 text-tertiary" aria-hidden />
          Notes & blocages
        </h3>

        <form onSubmit={addNote} className="flex items-center gap-2 mb-4">
          <select value={newNoteType} onChange={(e) => setNewNoteType(e.target.value)} className="input w-auto" aria-label="Type de note">
            <option value="note">Note</option>
            <option value="blocage">Blocage</option>
          </select>
          <input
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder="Ajouter une note ou signaler un blocage…"
            aria-label="Texte de la note"
            className="input flex-1"
          />
          <button type="submit" className="btn-icon" aria-label="Ajouter la note" disabled={!newNote.trim()}>
            <Plus className="w-4 h-4" />
          </button>
        </form>

        {notes.length === 0 ? (
          <p className="text-xs text-center py-4 text-tertiary">Aucune note pour le moment.</p>
        ) : (
          <ul className="space-y-2">
            {notes.map((note) => {
              const author = findById(data.teamMembers, note.author);
              const isBlocker = note.type === 'blocage';
              return (
                <li key={note.id} className={`note ${isBlocker ? 'note-blocker' : ''} group`}>
                  {isBlocker
                    ? <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0 text-danger" aria-label="Blocage" />
                    : <MessageSquare className="w-4 h-4 mt-0.5 shrink-0 text-tertiary" aria-hidden />}
                  <div className="flex-1 min-w-0">
                    <p className="text-xs mb-0.5">
                      <span className="font-medium text-secondary">{author?.name || 'Ancien membre'}</span>
                      <span className="text-tertiary">
                        {' · '}
                        {new Date(note.timestamp).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </p>
                    <p className="text-sm text-primary">{note.text}</p>
                  </div>
                  <button type="button" onClick={() => removeNote(note.id)} className="btn-icon opacity-0 group-hover:opacity-100 focus:opacity-100" aria-label="Supprimer la note">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </section>
  );
}

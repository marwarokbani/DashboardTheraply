/**
 * WelcomeScreen — État d'accueil quand l'espace est vide.
 *
 * « Commence par ajouter ta première tâche » : un champ de saisie rapide,
 * un lien vers la création d'un sprint, et un bouton optionnel pour
 * charger des données de démo.
 */
import { useState } from 'react';
import { ArrowRight, CornerDownLeft, Flag, Sparkles } from 'lucide-react';

export default function WelcomeScreen({ onAddTask, onNavigate, onLoadDemo }) {
  const [draft, setDraft] = useState('');

  const submit = (e) => {
    e.preventDefault();
    if (draft.trim() && onAddTask(draft)) setDraft('');
  };

  return (
    <div className="flex-1 flex items-center justify-center px-4 py-16">
      <div className="max-w-xl w-full text-center animate-fade-in-up">
        <img src="/LogoTheraply.png" alt="" className="w-14 h-14 mx-auto mb-6 object-contain" />
        <h1 className="text-2xl font-semibold tracking-tight text-primary mb-2">
          Commence par ajouter ta première tâche
        </h1>
        <p className="text-sm text-secondary mb-8">
          Toutes les statistiques du dashboard se construiront à partir de ce que tu saisis.
        </p>

        <form onSubmit={submit} className="quick-add mb-3">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Écrire l'API RDV @sahar #backend !haute 30/09"
            aria-label="Titre de la première tâche"
            className="flex-1 bg-transparent outline-none text-sm text-primary placeholder:text-[var(--text-tertiary)]"
            autoFocus
          />
          <button type="submit" className="btn btn-primary" disabled={!draft.trim()}>
            Ajouter <CornerDownLeft className="w-3.5 h-3.5" aria-hidden />
          </button>
        </form>
        <p className="text-xs text-tertiary mb-10">
          Optionnel : <code>@membre</code> <code>#module</code> <code>!haute</code> <code>30/09</code> <code>~3</code> (estimation)
        </p>

        <div className="flex flex-col sm:flex-row gap-2 justify-center">
          <button type="button" className="btn btn-secondary" onClick={() => onNavigate('settings')}>
            <Flag className="w-4 h-4" aria-hidden /> Créer un sprint <ArrowRight className="w-4 h-4" aria-hidden />
          </button>
          <button type="button" className="btn btn-ghost" onClick={onLoadDemo}>
            <Sparkles className="w-4 h-4" aria-hidden /> Charger des données de démo
          </button>
        </div>
      </div>
    </div>
  );
}

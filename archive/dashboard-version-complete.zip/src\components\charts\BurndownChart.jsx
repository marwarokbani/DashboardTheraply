/**
 * BurndownChart — Reste à faire du sprint : courbe idéale vs réelle,
 * plus le périmètre total (fait apparaître les ajouts en cours de sprint).
 */
import { Area, CartesianGrid, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { TrendingDown } from 'lucide-react';
import ChartCard, { ChartTooltip } from './ChartCard';
import { AXIS_PROPS } from './chartTheme';
import { todayISO } from '../../utils/dates';

export default function BurndownChart({ burndown, sprint, unit, actions, className }) {
  const today = todayISO();
  const todayPoint = burndown.points.find((p) => p.date === today);
  const unitLabel = unit === 'points' ? ' pts' : '';

  return (
    <ChartCard
      title="Burndown"
      subtitle={sprint ? `${sprint.name} · reste à faire ${unit === 'points' ? 'en points' : 'en tâches'}` : undefined}
      icon={TrendingDown}
      actions={actions}
      className={className}
      isEmpty={!burndown.hasData}
      empty={{
        title: sprint ? 'Pas encore de tâche dans ce sprint' : 'Aucun sprint sélectionné',
        message: sprint
          ? 'Ajoutez des tâches au sprint : la courbe se construira jour après jour.'
          : 'Créez un sprint dans Paramètres pour suivre son burndown.',
      }}
    >
      <div className="h-64" role="img" aria-label={`Burndown de ${sprint?.name}. Reste à faire aujourd'hui : ${todayPoint?.remaining ?? '—'}.`}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={burndown.points} margin={{ top: 20, right: 8, bottom: 0, left: -16 }}>
            <defs>
              <linearGradient id="burndown-fill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--accent)" stopOpacity={0.18} />
                <stop offset="100%" stopColor="var(--accent)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="var(--border-light)" />
            <XAxis dataKey="label" {...AXIS_PROPS} interval="preserveStartEnd" minTickGap={16} />
            <YAxis {...AXIS_PROPS} allowDecimals={false} width={40} />
            <Tooltip content={<ChartTooltip unitLabel={unitLabel} />} cursor={{ stroke: 'var(--border-strong)' }} />
            {todayPoint && <ReferenceLine x={todayPoint.label} stroke="var(--border-strong)" strokeDasharray="3 3" label={{ value: "Aujourd'hui", position: 'top', fill: 'var(--text-tertiary)', fontSize: 10 }} />}
            <Line type="linear" dataKey="ideal" name="Idéal" stroke="var(--text-tertiary)" strokeWidth={1.5} strokeDasharray="4 4" dot={false} isAnimationActive={false} />
            <Line type="stepAfter" dataKey="scope" name="Périmètre" stroke="var(--border-strong)" strokeWidth={1} dot={false} connectNulls={false} isAnimationActive={false} />
            <Area type="linear" dataKey="remaining" name="Réel" stroke="var(--accent)" strokeWidth={2} fill="url(#burndown-fill)" dot={false} activeDot={{ r: 4 }} connectNulls={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <ul className="chart-legend" aria-hidden>
        <li><span className="legend-line" style={{ borderColor: 'var(--accent)' }} /> Réel</li>
        <li><span className="legend-line legend-dashed" style={{ borderColor: 'var(--text-tertiary)' }} /> Idéal</li>
        <li><span className="legend-line" style={{ borderColor: 'var(--border-strong)' }} /> Périmètre</li>
      </ul>
    </ChartCard>
  );
}

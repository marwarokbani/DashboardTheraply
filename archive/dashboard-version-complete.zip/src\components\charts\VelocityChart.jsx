/**
 * VelocityChart — Planifié vs réalisé pour chaque sprint clôturé,
 * avec la moyenne des 3 derniers sprints.
 */
import { Bar, BarChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Gauge } from 'lucide-react';
import ChartCard, { ChartTooltip } from './ChartCard';
import { AXIS_PROPS } from './chartTheme';

export default function VelocityChart({ velocity, unit }) {
  const unitLabel = unit === 'points' ? ' pts' : '';

  return (
    <ChartCard
      title="Vélocité"
      subtitle={velocity.hasData ? `Moyenne des 3 derniers sprints : ${velocity.average}${unitLabel || ' tâches'}` : undefined}
      icon={Gauge}
      isEmpty={!velocity.hasData}
      empty={{ message: 'La vélocité apparaît après la clôture d’au moins un sprint.' }}
    >
      <div className="h-48" role="img" aria-label={velocity.rows.map((r) => `${r.name} : ${r.completed} réalisé sur ${r.planned} planifié`).join('. ')}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={velocity.rows} margin={{ top: 8, right: 8, bottom: 0, left: -16 }} barGap={4}>
            <CartesianGrid vertical={false} stroke="var(--border-light)" />
            <XAxis dataKey="name" {...AXIS_PROPS} />
            <YAxis {...AXIS_PROPS} allowDecimals={false} width={40} />
            <Tooltip content={<ChartTooltip unitLabel={unitLabel} />} cursor={{ fill: 'var(--bg-tertiary)' }} />
            <ReferenceLine y={velocity.average} stroke="var(--text-tertiary)" strokeDasharray="4 4" />
            <Bar dataKey="planned" name="Planifié" fill="var(--border-strong)" radius={[4, 4, 0, 0]} maxBarSize={28} />
            <Bar dataKey="completed" name="Réalisé" fill="var(--accent)" radius={[4, 4, 0, 0]} maxBarSize={28} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <ul className="chart-legend" aria-hidden>
        <li><span className="w-2 h-2 rounded-sm" style={{ background: 'var(--border-strong)' }} /> Planifié</li>
        <li><span className="w-2 h-2 rounded-sm" style={{ background: 'var(--accent)' }} /> Réalisé</li>
        <li><span className="legend-line legend-dashed" style={{ borderColor: 'var(--text-tertiary)' }} /> Moyenne</li>
      </ul>
    </ChartCard>
  );
}

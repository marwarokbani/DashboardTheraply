/**
 * ScopeSelect — Filtre global du périmètre (sprint actif, un autre sprint,
 * backlog, tout le projet). S'applique aux statistiques et aux tâches.
 */
import { IterationCw } from 'lucide-react';
import { getActiveSprint, getClosedSprints, getPlannedSprints } from '../../utils/sprints';

export default function ScopeSelect({ sprints, value, onChange }) {
  const active = getActiveSprint(sprints);
  const planned = getPlannedSprints(sprints);
  const closed = getClosedSprints(sprints).reverse();

  return (
    <label className="scope-select" title="Périmètre des statistiques et des tâches">
      <IterationCw className="w-3.5 h-3.5 text-tertiary shrink-0" aria-hidden />
      <span className="sr-only">Périmètre</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="active">{active ? `${active.name} (actif)` : 'Sprint actif (aucun)'}</option>
        {planned.length > 0 && (
          <optgroup label="Planifiés">
            {planned.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </optgroup>
        )}
        {closed.length > 0 && (
          <optgroup label="Clôturés">
            {closed.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </optgroup>
        )}
        <option value="backlog">Backlog (sans sprint)</option>
        <option value="all">Tout le projet</option>
      </select>
    </label>
  );
}

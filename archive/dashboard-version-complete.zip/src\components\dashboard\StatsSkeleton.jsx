/**
 * StatsSkeleton — Squelette affiché pendant le chargement des graphiques
 * (la librairie de graphiques est chargée à la demande).
 */
function SkeletonCard({ className = '', height = 'h-48' }) {
  return (
    <div className={`card p-5 ${className}`} aria-hidden>
      <div className="skeleton h-4 w-32 mb-5" />
      <div className={`skeleton ${height} w-full`} />
    </div>
  );
}

export default function StatsSkeleton() {
  return (
    <div className="space-y-4" role="status" aria-label="Chargement des graphiques">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <SkeletonCard className="xl:col-span-2" height="h-64" />
        <SkeletonCard height="h-64" />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        <SkeletonCard />
        <SkeletonCard />
        <SkeletonCard />
      </div>
    </div>
  );
}

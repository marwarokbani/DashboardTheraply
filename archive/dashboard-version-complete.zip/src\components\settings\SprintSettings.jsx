/**
 * SprintSettings — Gestion des sprints.
 *
 * - Sprint actif : modifier, clôturer (avec choix pour les tâches non terminées)
 * - Sprints planifiés : démarrer, supprimer
 * - Création d'un sprint (champs pré-remplis avec la suite logique)
 * - Historique des sprints clôturés (photo planifié / réalisé)
 */
import { useState } from 'react';
import { Calendar, Flag, Pencil, Play, Plus, Trash2 } from 'lucide-react';
import {
  closeSprint, createSprint, deleteSprint, getActiveSprint, getClosedSprints,
  getPlannedSprints, getSprintTasks, startSprint, suggestNextSprint, updateSprint, validateSprint,
} from '../../utils/sprints';
import { formatDateMedium, diffDays, todayISO } from '../../utils/dates';

// ============================================
// Formulaire de sprint (création / modification)
// ============================================

function SprintForm({ initial, submitLabel, onSubmit, onCancel }) {
  const [fields, setFields] = useState(initial);
  const [error, setError] = useState(null);
  const set = (key) => (e) => setFields((f) => ({ ...f, [key]: e.target.value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    const message = validateSprint(fields);
    if (message) {
      setError(message);
      return;
    }
    onSubmit(fields);
  };

  return (
    <form onSubmit={handleSubmit} className="settings-card space-y-3">
      <label className="field">
        <span className="field-label">Nom *</span>
        <input className="input" value={fields.name} onChange={set('name')} placeholder="Sprint 8" autoFocus />
      </label>
      <div className="grid grid-cols-2 gap-3">
        <label className="field">
          <span className="field-label">Début *</span>
          <input className="input" type="date" value={fields.startDate} onChange={set('startDate')} />
        </label>
        <label className="field">
          <span className="field-label">Fin *</span>
          <input className="input" type="date" value={fields.endDate} onChange={set('endDate')} />
        </label>
      </div>
      <label className="field">
        <span className="field-label">Objectif</span>
        <textarea className="input resize-none" rows={2} value={fields.goal} onChange={set('goal')} placeholder="Ce que ce sprint doit livrer" />
      </label>
      {error && <p role="alert" className="text-xs text-danger">{error}</p>}
      <div className="flex gap-2">
        <button type="submit" className="btn btn-primary flex-1">{submitLabel}</button>
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Annuler</button>
      </div>
    </form>
  );
}

// ============================================
// Dialogue de clôture
// ============================================

function CloseSprintPanel({ sprint, sprints, tasks, onConfirm, onCancel }) {
  const unfinished = getSprintTasks(tasks, sprint.id).filter((t) => t.status !== 'done');
  const planned = getPlannedSprints(sprints);
  const [mode, setMode] = useState('next');
  // Destination du report : un sprint planifié existant, ou « new » pour en créer un
  const [target, setTarget] = useState(planned[0]?.id || 'new');
  const [nextFields, setNextFields] = useState(() => suggestNextSprint(sprint));
  const [error, setError] = useState(null);

  const confirm = () => {
    if (mode === 'next' && target === 'new') {
      const message = validateSprint(nextFields);
      if (message) {
        setError(message);
        return;
      }
    }
    onConfirm({
      carryOver: mode,
      nextSprintId: mode === 'next' && target !== 'new' ? target : null,
      nextSprintFields: mode === 'next' && target === 'new' ? nextFields : null,
    });
  };

  const options = [
    { value: 'next', label: 'Reporter au sprint suivant', desc: 'Recommandé : elles restent visibles et comptent dans le prochain burndown.' },
    { value: 'keep', label: 'Les laisser dans ce sprint', desc: 'Elles restent non terminées dans l’historique du sprint clôturé.' },
    { value: 'backlog', label: 'Les remettre dans le backlog', desc: 'Sans sprint, à replanifier plus tard.' },
  ];

  return (
    <div className="settings-card space-y-4" role="region" aria-label={`Clôturer ${sprint.name}`}>
      <div>
        <p className="text-sm font-semibold text-primary">Clôturer {sprint.name}</p>
        <p className="text-xs text-tertiary mt-1">
          {unfinished.length === 0
            ? 'Toutes les tâches sont terminées.'
            : `${unfinished.length} tâche${unfinished.length > 1 ? 's' : ''} non terminée${unfinished.length > 1 ? 's' : ''}. Que faire ?`}
        </p>
      </div>

      {unfinished.length > 0 && (
        <fieldset className="space-y-2">
          <legend className="sr-only">Tâches non terminées</legend>
          {options.map((opt) => (
            <label key={opt.value} className={`choice ${mode === opt.value ? 'choice-selected' : ''}`}>
              <input type="radio" name="carry-over" value={opt.value} checked={mode === opt.value} onChange={() => setMode(opt.value)} className="mt-0.5 accent-[var(--accent)]" />
              <span>
                <span className="block text-sm font-medium text-primary">{opt.label}</span>
                <span className="block text-xs text-tertiary">{opt.desc}</span>
              </span>
            </label>
          ))}
        </fieldset>
      )}

      {mode === 'next' && (
        <div className="space-y-3">
          {planned.length > 0 && (
            <label className="field">
              <span className="field-label">Sprint de destination</span>
              <select className="input" value={target} onChange={(e) => setTarget(e.target.value)}>
                {planned.map((s) => <option key={s.id} value={s.id}>{s.name} ({formatDateMedium(s.startDate)})</option>)}
                <option value="new">Créer un nouveau sprint…</option>
              </select>
            </label>
          )}
          {target === 'new' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input className="input" aria-label="Nom du nouveau sprint" value={nextFields.name} onChange={(e) => setNextFields((f) => ({ ...f, name: e.target.value }))} />
              <input className="input" aria-label="Début du nouveau sprint" type="date" value={nextFields.startDate} onChange={(e) => setNextFields((f) => ({ ...f, startDate: e.target.value }))} />
              <input className="input" aria-label="Fin du nouveau sprint" type="date" value={nextFields.endDate} onChange={(e) => setNextFields((f) => ({ ...f, endDate: e.target.value }))} />
            </div>
          )}
        </div>
      )}

      {error && <p role="alert" className="text-xs text-danger">{error}</p>}
      <div className="flex gap-2">
        <button type="button" className="btn btn-danger flex-1" onClick={confirm}>Confirmer la clôture</button>
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Annuler</button>
      </div>
    </div>
  );
}

// ============================================
// Ligne de sprint
// ============================================

function SprintDates({ sprint }) {
  return (
    <span className="inline-flex items-center gap-1 text-xs text-tertiary">
      <Calendar className="w-3 h-3" aria-hidden />
      {formatDateMedium(sprint.startDate)} → {formatDateMedium(sprint.endDate)}
    </span>
  );
}

// ============================================
// Composant principal
// ============================================

export default function SprintSettings({ data, updateData, showToast }) {
  const [panel, setPanel] = useState(null); // null | 'create' | 'close' | { edit: sprintId }
  const { sprints, tasks } = data;
  const active = getActiveSprint(sprints);
  const planned = getPlannedSprints(sprints);
  const closed = getClosedSprints(sprints).reverse();
  const lastSprint = active || planned.at(-1) || closed[0] || null;

  const handleCreate = (fields) => {
    const sprint = createSprint(fields, { sprints });
    updateData((prev) => ({ ...prev, sprints: [...prev.sprints, sprint] }));
    setPanel(null);
    showToast(sprint.status === 'active' ? `${sprint.name} créé et démarré` : `${sprint.name} planifié`);
  };

  const handleEdit = (sprintId, fields) => {
    updateData((prev) => ({
      ...prev,
      sprints: updateSprint(prev.sprints, sprintId, { name: fields.name.trim(), startDate: fields.startDate, endDate: fields.endDate, goal: fields.goal.trim() }),
    }));
    setPanel(null);
  };

  const handleClose = (options) => {
    updateData((prev) => {
      const result = closeSprint({ sprints: prev.sprints, tasks: prev.tasks }, { sprintId: active.id, ...options });
      return { ...prev, sprints: result.sprints, tasks: result.tasks };
    });
    setPanel(null);
    showToast(`${active.name} clôturé`);
  };

  const handleStart = (sprint) => {
    updateData((prev) => ({ ...prev, sprints: startSprint(prev.sprints, sprint.id) }));
    showToast(`${sprint.name} démarré`);
  };

  const handleDelete = (sprint) => {
    const count = getSprintTasks(tasks, sprint.id).length;
    const detail = count ? ` Ses ${count} tâche(s) retourneront dans le backlog.` : '';
    if (!confirm(`Supprimer ${sprint.name} ?${detail}`)) return;
    updateData((prev) => ({ ...prev, ...deleteSprint(prev, sprint.id) }));
  };

  return (
    <div className="space-y-6">
      {/* ── Sprint actif ── */}
      <section aria-labelledby="active-sprint-title" className="space-y-3">
        <h3 id="active-sprint-title" className="settings-heading">Sprint actif</h3>
        {active ? (
          panel?.edit === active.id ? (
            <SprintForm initial={active} submitLabel="Enregistrer" onSubmit={(f) => handleEdit(active.id, f)} onCancel={() => setPanel(null)} />
          ) : (
            <div className="settings-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-primary flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[var(--status-done)]" aria-hidden />
                    {active.name}
                  </p>
                  {active.goal && <p className="text-xs text-secondary mt-1">{active.goal}</p>}
                  <div className="flex flex-wrap gap-3 mt-2">
                    <SprintDates sprint={active} />
                    <span className="text-xs text-tertiary">
                      {getSprintTasks(tasks, active.id).length} tâches ·{' '}
                      {Math.max(0, diffDays(todayISO(), active.endDate) ?? 0)} j restants
                    </span>
                  </div>
                </div>
                <div className="flex gap-1 shrink-0">
                  <button type="button" className="btn-icon" onClick={() => setPanel({ edit: active.id })} aria-label={`Modifier ${active.name}`}>
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button type="button" className="btn btn-danger-ghost" onClick={() => setPanel('close')}>
                    <Flag className="w-4 h-4" /> Clôturer
                  </button>
                </div>
              </div>
            </div>
          )
        ) : (
          <p className="settings-empty">Aucun sprint actif. Créez-en un ou démarrez un sprint planifié.</p>
        )}
        {panel === 'close' && active && (
          <CloseSprintPanel sprint={active} sprints={sprints} tasks={tasks} onConfirm={handleClose} onCancel={() => setPanel(null)} />
        )}
      </section>

      {/* ── Sprints planifiés ── */}
      {planned.length > 0 && (
        <section aria-labelledby="planned-sprints-title" className="space-y-2">
          <h3 id="planned-sprints-title" className="settings-heading">Planifiés</h3>
          {planned.map((sprint) =>
            panel?.edit === sprint.id ? (
              <SprintForm key={sprint.id} initial={sprint} submitLabel="Enregistrer" onSubmit={(f) => handleEdit(sprint.id, f)} onCancel={() => setPanel(null)} />
            ) : (
              <div key={sprint.id} className="settings-row">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-primary">{sprint.name}</p>
                  <SprintDates sprint={sprint} />
                </div>
                {!active && (
                  <button type="button" className="btn btn-secondary" onClick={() => handleStart(sprint)}>
                    <Play className="w-3.5 h-3.5" /> Démarrer
                  </button>
                )}
                <button type="button" className="btn-icon" onClick={() => setPanel({ edit: sprint.id })} aria-label={`Modifier ${sprint.name}`}>
                  <Pencil className="w-4 h-4" />
                </button>
                <button type="button" className="btn-icon btn-icon-danger" onClick={() => handleDelete(sprint)} aria-label={`Supprimer ${sprint.name}`}>
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )
          )}
        </section>
      )}

      {/* ── Création ── */}
      {panel === 'create' ? (
        <SprintForm initial={suggestNextSprint(lastSprint)} submitLabel={active ? 'Planifier le sprint' : 'Créer et démarrer'} onSubmit={handleCreate} onCancel={() => setPanel(null)} />
      ) : (
        <button type="button" className="btn-dashed" onClick={() => setPanel('create')}>
          <Plus className="w-4 h-4" /> {active ? 'Planifier le sprint suivant' : 'Créer un sprint'}
        </button>
      )}

      {/* ── Historique ── */}
      {closed.length > 0 && (
        <section aria-labelledby="closed-sprints-title" className="space-y-2">
          <h3 id="closed-sprints-title" className="settings-heading">Clôturés</h3>
          {closed.map((sprint) => {
            const snap = sprint.snapshot;
            const committed = snap ? snap.plannedTasks + snap.addedTasks : 0;
            return (
              <div key={sprint.id} className="settings-row">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-secondary">{sprint.name}</p>
                  <SprintDates sprint={sprint} />
                </div>
                {snap && (
                  <span className="text-xs text-tertiary tabular-nums text-right">
                    {snap.completedTasks}/{committed} réalisées
                    {snap.addedTasks > 0 && <span className="block">dont {snap.addedTasks} ajoutée{snap.addedTasks > 1 ? 's' : ''} en cours</span>}
                  </span>
                )}
              </div>
            );
          })}
        </section>
      )}
    </div>
  );
}

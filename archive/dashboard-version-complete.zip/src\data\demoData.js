/**
 * demoData.js — Données de démonstration OPTIONNELLES.
 *
 * Jamais chargées automatiquement : uniquement via le bouton
 * « Charger des données de démo ». Toutes les dates sont calculées
 * par rapport à aujourd'hui pour que les stats aient du sens.
 */

import { DEFAULT_MODULES, DEFAULT_SETTINGS, DEFAULT_TEAM_MEMBERS } from './initialData.js';
import { addDays, parseISODate, todayISO } from '../utils/dates.js';
import { computeSprintSnapshot } from '../utils/sprints.js';

/**
 * Construit l'état de démo.
 * @param {Date} now
 */
export function getDemoState(now = new Date()) {
  const today = todayISO(now);
  const day = (offset) => addDays(today, offset);
  // Horodatage à une heure donnée d'un jour relatif (ex : at(-2, 15) = avant-hier 15 h)
  const at = (offset, hour = 10) => {
    const d = parseISODate(day(offset));
    d.setHours(hour, 0, 0, 0);
    return d.toISOString();
  };

  const previousSprint = {
    id: 'demo-sprint-6',
    name: 'Sprint 6',
    goal: 'Poser les fondations : maquettes, architecture, sécurité',
    startDate: day(-19),
    endDate: day(-6),
    status: 'closed',
    createdAt: at(-19, 9),
    closedAt: at(-6, 18),
    snapshot: null,
    carryOver: { mode: 'next', toSprintId: 'demo-sprint-7' },
  };

  const activeSprint = {
    id: 'demo-sprint-7',
    name: 'Sprint 7',
    goal: "Finaliser l'authentification et les interfaces principales",
    startDate: day(-5),
    endDate: day(8),
    status: 'active',
    createdAt: at(-6, 18),
    closedAt: null,
    snapshot: null,
    carryOver: null,
  };

  /** Raccourci de création d'une tâche de démo. */
  const task = (id, fields) => ({
    id: `demo-task-${id}`,
    description: '',
    priority: 'moyenne',
    status: 'todo',
    dueDate: null,
    estimate: null,
    sprintId: activeSprint.id,
    createdAt: at(-5, 9),
    sprintAssignedAt: at(-5, 9),
    completedAt: null,
    ...fields,
  });

  // Tâches du sprint 6 (clôturé) — historique pour la vélocité
  const sprint6Tasks = [
    task('s6-1', { title: 'Maquettes UI/UX du parcours patient', assignee: 'sahar', module: 'patient', status: 'done', estimate: 5, sprintId: previousSprint.id, createdAt: at(-19, 9), sprintAssignedAt: at(-19, 9), completedAt: at(-15, 16), dueDate: day(-15) }),
    task('s6-2', { title: 'Architecture Spring Boot et modules Maven', assignee: 'marwa', module: 'backend', priority: 'haute', status: 'done', estimate: 8, sprintId: previousSprint.id, createdAt: at(-19, 9), sprintAssignedAt: at(-19, 9), completedAt: at(-12, 11), dueDate: day(-12) }),
    task('s6-3', { title: 'Schéma de base de données initial', assignee: 'marwa', module: 'backend', status: 'done', estimate: 5, sprintId: previousSprint.id, createdAt: at(-19, 9), sprintAssignedAt: at(-19, 9), completedAt: at(-9, 14), dueDate: day(-9) }),
    task('s6-4', { title: 'Panneau de modération (version 1)', assignee: 'sahar', module: 'admin', priority: 'basse', status: 'done', estimate: 3, sprintId: previousSprint.id, createdAt: at(-14, 9), sprintAssignedAt: at(-14, 9), completedAt: at(-7, 17), dueDate: day(-7) }),
  ];

  // Tâches du sprint 7 (actif)
  const sprint7Tasks = [
    task(1, { title: "Implémenter l'authentification JWT côté patient", description: 'JWT + refresh token, stockage sécurisé, déconnexion automatique.', assignee: 'marwa', module: 'patient', priority: 'haute', status: 'done', dueDate: day(-3), completedAt: at(-3, 17), estimate: 8 }),
    task(2, { title: 'Configurer Spring Security avec JWT', assignee: 'marwa', module: 'backend', priority: 'haute', status: 'done', dueDate: day(-4), completedAt: at(-4, 15), estimate: 5 }),
    task(3, { title: "Formulaire d'inscription patient", description: 'Validation côté client et côté serveur, gestion des erreurs.', assignee: 'marwa', module: 'patient', status: 'done', dueDate: day(-2), completedAt: at(-1, 11), estimate: 5 }),
    task(4, { title: 'Endpoints REST des rendez-vous', description: 'CRUD complet + pagination.', assignee: 'sahar', module: 'backend', priority: 'haute', status: 'done', dueDate: day(-1), completedAt: at(-1, 16), estimate: 8 }),
    task(5, { title: 'Interface de recherche de thérapeutes', description: 'Filtres par spécialité, localisation, disponibilité.', assignee: 'sahar', module: 'patient', priority: 'haute', status: 'in-progress', dueDate: day(2), estimate: 8 }),
    task(6, { title: 'Gestion du calendrier de rendez-vous', assignee: 'marwa', module: 'therapeute', priority: 'haute', status: 'in-progress', dueDate: day(3), estimate: 13 }),
    task(7, { title: 'Service de matching IA thérapeute-patient', description: 'Algorithme de scoring basé sur les préférences.', assignee: 'marwa', module: 'ia', priority: 'haute', status: 'in-progress', dueDate: day(4), estimate: 13, createdAt: at(-2, 10), sprintAssignedAt: at(-2, 10) }),
    task(8, { title: 'Tableau de bord thérapeute', description: "Vue d'ensemble : prochains RDV, stats, messages.", assignee: 'sahar', module: 'therapeute', priority: 'haute', status: 'in-review', dueDate: day(1), estimate: 5 }),
    task(9, { title: 'Service de notifications par e-mail', assignee: 'marwa', module: 'backend', status: 'in-review', dueDate: day(0), estimate: 3 }),
    task(10, { title: 'Interface de messagerie sécurisée', description: 'Chiffrement de bout en bout, fil de discussion par patient.', assignee: 'sahar', module: 'therapeute', status: 'todo', dueDate: day(5), estimate: 8 }),
    task(11, { title: 'Interface du journal intelligent', description: 'Journal guidé par IA, suggestions personnalisées.', assignee: 'sahar', module: 'ia', priority: 'haute', status: 'todo', dueDate: day(6), estimate: 8, createdAt: at(-1, 14), sprintAssignedAt: at(-1, 14) }),
    task(12, { title: 'Configurer le RAG personnel pour les recommandations', assignee: 'marwa', module: 'ia', status: 'todo', dueDate: day(7), createdAt: at(0, 9), sprintAssignedAt: at(0, 9) }),
    // Reportée depuis le sprint 6, et désormais en retard
    task(13, { title: 'Agent de sécurité IA (détection de crise)', description: 'Priorité critique : détection de messages à risque.', assignee: 'sahar', module: 'ia', priority: 'haute', status: 'todo', dueDate: day(-1), estimate: 13, createdAt: at(-16, 9), sprintAssignedAt: at(-6, 18) }),
    task(14, { title: 'Notifications push côté patient', assignee: 'sahar', module: 'patient', priority: 'basse', status: 'todo', dueDate: day(-2), estimate: 3 }),
  ];

  // Backlog (hors sprint)
  const backlog = [
    task(15, { title: 'Système de paiement intégré', assignee: null, module: 'patient', sprintId: null, sprintAssignedAt: null, estimate: 13 }),
    task(16, { title: 'Déploiement CI/CD et monitoring', assignee: 'marwa', module: 'backend', priority: 'basse', sprintId: null, sprintAssignedAt: null }),
  ];

  // La tâche 13 appartenait au sprint 6 au moment de sa clôture : on l'y
  // replace le temps de calculer la photo, puis on la laisse dans le sprint 7.
  const snapshotTasks = [
    ...sprint6Tasks,
    { ...sprint7Tasks[12], sprintId: previousSprint.id, sprintAssignedAt: at(-16, 9) },
  ];
  previousSprint.snapshot = computeSprintSnapshot(previousSprint, snapshotTasks, parseISODate(day(-6)));

  const milestone = (id, module, title, completedOffset = null) => ({
    id: `demo-ms-${id}`,
    module,
    title,
    completed: completedOffset !== null,
    completedAt: completedOffset !== null ? at(completedOffset, 17) : null,
    dueDate: null,
  });

  return {
    tasks: [...sprint6Tasks, ...sprint7Tasks, ...backlog],
    milestones: [
      milestone(1, 'patient', 'Maquettes UI/UX validées', -15),
      milestone(2, 'patient', 'Authentification et inscription', -1),
      milestone(3, 'patient', 'Recherche et filtrage des thérapeutes'),
      milestone(4, 'patient', 'Réservation de séances'),
      milestone(5, 'therapeute', 'Dashboard thérapeute fonctionnel'),
      milestone(6, 'therapeute', 'Gestion du calendrier'),
      milestone(7, 'therapeute', 'Messagerie sécurisée'),
      milestone(8, 'ia', 'Algorithme de matching'),
      milestone(9, 'ia', 'Pipeline RAG personnel'),
      milestone(10, 'ia', 'Agent de sécurité (détection de crise)'),
      milestone(11, 'admin', 'Panneau de modération', -7),
      milestone(12, 'admin', 'Gestion des utilisateurs et rôles'),
      milestone(13, 'backend', 'Architecture Spring Boot et sécurité JWT', -4),
      milestone(14, 'backend', 'API REST complète'),
      milestone(15, 'backend', 'Déploiement CI/CD'),
    ],
    notes: [
      { id: 'demo-note-1', author: 'marwa', type: 'blocage', text: "En attente de la clé API pour le service de matching. Relancer l'équipe infra.", timestamp: at(-1, 9) },
      { id: 'demo-note-2', author: 'sahar', type: 'note', text: 'Le composant calendrier a besoin de tests supplémentaires sur mobile.', timestamp: at(-1, 15) },
    ],
    sprints: [previousSprint, activeSprint],
    teamMembers: DEFAULT_TEAM_MEMBERS.map((m) => ({ ...m })),
    modules: DEFAULT_MODULES.map((m) => ({ ...m })),
    settings: { ...DEFAULT_SETTINGS },
  };
}

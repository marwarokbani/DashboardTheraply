/**
 * initialData.js — Constantes fixes et état initial VIDE du dashboard.
 *
 * Les données métier (tâches, sprints, membres, modules, jalons, notes)
 * vivent dans le localStorage via useSaveData : rien n'est codé en dur ici
 * à part les listes fixes (statuts, priorités) et la configuration de
 * départ de l'équipe, entièrement éditable depuis la page Paramètres.
 */

/** Version courante du format de sauvegarde (voir data/migrations.js). */
export const DATA_VERSION = 3;

// ============================================
// Statuts de tâche (fixes)
// ============================================

export const STATUSES = [
  { id: 'todo', label: 'À faire' },
  { id: 'in-progress', label: 'En cours' },
  { id: 'in-review', label: 'En revue' },
  { id: 'done', label: 'Terminé' },
];

export const STATUS_IDS = STATUSES.map((s) => s.id);

// ============================================
// Priorités (fixes, de la plus urgente à la moins urgente)
// ============================================

export const PRIORITIES = [
  { id: 'haute', label: 'Haute' },
  { id: 'moyenne', label: 'Moyenne' },
  { id: 'basse', label: 'Basse' },
];

export const PRIORITY_IDS = PRIORITIES.map((p) => p.id);

// ============================================
// Configuration de départ de l'équipe Theraply
// (sert uniquement à initialiser un nouvel espace ; éditable ensuite)
// ============================================

export const DEFAULT_TEAM_MEMBERS = [
  { id: 'marwa', name: 'Marwa', role: 'Cheffe de projet & Dev', color: '#7c3aed' },
  { id: 'sahar', name: 'Sahar', role: 'Développeuse', color: '#0284c7' },
];

export const DEFAULT_MODULES = [
  { id: 'patient', name: 'Application Patient', color: '#7c3aed' },
  { id: 'therapeute', name: 'Application Thérapeute', color: '#0284c7' },
  { id: 'ia', name: 'Services IA', color: '#c026d3' },
  { id: 'admin', name: 'Administration', color: '#d97706' },
  { id: 'backend', name: 'Backend (Spring Boot)', color: '#059669' },
];

export const DEFAULT_SETTINGS = {
  autoSave: true,
  autoSaveInterval: 120000, // 2 minutes
  currentUserId: 'marwa', // « moi » : assignée par défaut des nouvelles tâches
};

// ============================================
// État initial VIDE (premier lancement)
// ============================================

/**
 * Espace vide : aucune tâche, aucun sprint, aucun jalon.
 * L'écran d'accueil propose « Commence par ajouter ta première tâche »
 * et un bouton optionnel « Charger des données de démo ».
 */
export function getEmptyState() {
  return {
    tasks: [],
    milestones: [],
    notes: [],
    sprints: [],
    teamMembers: DEFAULT_TEAM_MEMBERS.map((m) => ({ ...m })),
    modules: DEFAULT_MODULES.map((m) => ({ ...m })),
    settings: { ...DEFAULT_SETTINGS },
  };
}

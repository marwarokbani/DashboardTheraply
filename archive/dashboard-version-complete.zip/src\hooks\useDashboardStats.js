/**
 * useDashboardStats — Calcule toutes les statistiques du dashboard en une fois.
 *
 * Recalcul instantané à chaque modification de `data` ou des filtres
 * (useMemo). Les composants ne font qu'afficher le résultat.
 *
 * @param {object} data
 * @param {{ scope?: 'active'|'all'|string, unit?: 'tasks'|'points', moduleMode?: 'tasks'|'milestones' }} filters
 */
import { useMemo } from 'react';
import {
  getScope, calcProgress, calcCompletedThisWeek, calcOverdue, calcDueSoon, getTodayFocus,
  calcSprintTimeline, calcBurndown, calcVelocity, calcStatusDistribution,
  calcModuleProgress, calcWorkloadByMember,
} from '../utils/stats';

export function useDashboardStats(data, { scope = 'active', unit: requestedUnit = 'tasks', moduleMode = 'tasks' } = {}) {
  return useMemo(() => {
    const now = new Date();
    const scoped = getScope(data, scope);
    const { tasks, sprint } = scoped;
    // L'unité « points » n'a de sens que si des estimations existent
    const hasEstimates = data.tasks.some((t) => Number(t.estimate) > 0);
    const unit = hasEstimates ? requestedUnit : 'tasks';
    const progress = calcProgress(tasks, { unit, now });

    return {
      scope: scoped,
      unit,
      hasEstimates,
      kpis: {
        progress,
        completedThisWeek: calcCompletedThisWeek(tasks, { now }),
        overdue: calcOverdue(tasks, { now }),
        timeline: calcSprintTimeline(sprint, progress.percent, { now }),
      },
      dueSoon: calcDueSoon(tasks, { now }),
      todayFocus: getTodayFocus(tasks, { now }),
      burndown: calcBurndown(sprint, data.tasks, { unit, now }),
      velocity: calcVelocity(data.sprints, data.tasks, { unit }),
      statusDistribution: calcStatusDistribution(tasks, { unit }),
      moduleProgress: calcModuleProgress(data.modules, { tasks, milestones: data.milestones, mode: moduleMode, unit }),
      workload: calcWorkloadByMember(tasks, data.teamMembers, { unit, now }),
    };
  }, [data, scope, requestedUnit, moduleMode]);
}

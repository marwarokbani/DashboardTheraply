/**
 * milestones.js — Jalons du projet (fonctions pures).
 *
 * Jalon : { id, title, module: string|null, completed: boolean, completedAt: ISO|null, dueDate: 'YYYY-MM-DD'|null }
 */

import { generateId } from './ids.js';

export function addMilestone(milestones, { title, module = null, dueDate = null }) {
  return [
    ...milestones,
    { id: generateId('milestone'), title: title.trim(), module, completed: false, completedAt: null, dueDate },
  ];
}

export function updateMilestone(milestones, milestoneId, patch) {
  return milestones.map((ms) => (ms.id === milestoneId ? { ...ms, ...patch } : ms));
}

/** Coche / décoche un jalon et date sa complétion. */
export function toggleMilestone(milestones, milestoneId, now = new Date()) {
  return milestones.map((ms) =>
    ms.id === milestoneId
      ? { ...ms, completed: !ms.completed, completedAt: ms.completed ? null : now.toISOString() }
      : ms
  );
}

export function removeMilestone(milestones, milestoneId) {
  return milestones.filter((ms) => ms.id !== milestoneId);
}
